import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Maya_Maze extends PApplet {

PImage mainRoom;
PImage rightRoom;
PImage leftRoom;
PImage finalRoom;
PImage statueEye;
PImage statueGem;
PImage eyeIcon;
PImage eyeIconSmall;
PImage gemIcon;
PImage doorOpens;
//PImage doorOpensAnim;
PImage mouseHalo;

//images for the left room puzzle
PImage leftPuzzleBackground;
PImage leftRoomRoots;
PImage leftPuzzlePiece0;
PImage leftPuzzlePiece1;
PImage leftPuzzlePiece2;
PImage leftPuzzlePiece3;

//images for the right room puzzle
PImage rightPuzzlePiece00;
PImage rightPuzzlePiece01;
PImage rightPuzzlePiece02;
PImage rightPuzzlePiece03;

PImage rightPuzzlePiece04;
PImage rightPuzzlePiece05;
PImage rightPuzzlePiece06;
PImage rightPuzzlePiece07;

PImage rightPuzzlePiece08;
PImage rightPuzzlePiece09;
PImage rightPuzzlePiece10;
PImage rightPuzzlePiece11;

PImage rightPuzzlePiece12;
PImage rightPuzzlePiece13;
PImage rightPuzzlePiece14;
PImage rightPuzzlePiece15;


String currentScene = "main_Scene";


int itemX;
int itemY = 1025;

int itemSelected;

boolean foundEye = false;
boolean returnedEye = false;

boolean foundGem = false;
boolean returnedGem = false;

boolean doorUnlocked = false;

//booleans for left room puzzle
boolean leftSolved = false;
boolean middleSolved = false;
boolean rightSolved = false;

boolean topRightSolved = false;
boolean topLeftSolved = false;
boolean bottomRightSolved = false;
boolean bottomLeftSolved = false;

boolean rightPuzzleSolved = false;
boolean leftPuzzleSolved = false;

Main_Scene mainScene = new Main_Scene();
Right_Scene rightScene = new Right_Scene();
Left_Scene leftScene = new Left_Scene();
Final_Scene finalScene = new Final_Scene();
//Door_Opens_Anim DoorOpensAnim = new Door_Opens_Anim(doorOpensAnim, 11, 1);

Left_Puzzle leftPuzzleScene = new Left_Puzzle();

leftPuzzle leftPiece = new leftPuzzle();
leftPuzzle middlePiece = new leftPuzzle();
leftPuzzle rightPiece = new leftPuzzle();

rightPuzzle trPiece = new rightPuzzle();
rightPuzzle tlPiece = new rightPuzzle();
rightPuzzle brPiece = new rightPuzzle();
rightPuzzle blPiece = new rightPuzzle();

GameObject Eye;
GameObject Gem;

ArrayList<Item> Inventory = new ArrayList();

public void setup()
{
   
  //1080p screens only!!! higher resolusion will work but is wonky.
  //lower resolution will make game unplayable.

  LoadImages();
  Eye = new GameObject(eyeIcon, 800, 400, "Eye", 300, 300);
  Gem = new GameObject(gemIcon, 937, 440, "Gem", 50, 50);
}

public void draw()
{
  background(0);
  
  QuitOnEscPress();
  
  imageMode(CORNER);
  SceneManager();
  
  imageMode(CENTER);
  DrawInventory();
  
  //if (doorUnlocked = true)
  //{
  //  DoorOpensAnim.next();
  //  DoorOpensAnim.draw(320, 0);
  //}
      
}

public void DrawInventory()
{
  fill(128);
  rect(320, 960, 1280, 120); //inventory bar
  
  itemX = 425;
  
  for (int i = 0; i < Inventory.size(); ++i) // draw every item in inventory
  {
    Item item = Inventory.get(i);
    
    if (item != null)
    {
      item.itemX = itemX;
      item.draw();
      itemX += 200;
    }
    else
    {
      itemX -= 200;
    }
  }
}

public Item itemName (String name)
  {
    for (Item item : Inventory)
    {
      if (item.itemName().equals(name))
      {
        return item;
      }
    }
    return null;
  }

public void LoadImages()
{
  mainRoom = loadImage("Main_Room.png");
  rightRoom = loadImage("Right_Room.png");
  leftRoom = loadImage("Left_Room.jpg");
  finalRoom = loadImage("Final_Room.png");
  statueEye = loadImage("Statue_Eye.png");
  statueGem = loadImage("Statue_Gem.png");
  eyeIcon = loadImage("eye300x300.png");
  eyeIconSmall = loadImage("eye30x30.png");
  gemIcon = loadImage("Gem300x300.png");
  doorOpens = loadImage("Door_Open.gif");
  //doorOpensAnim = loadImage("Door_Opens_Anim.png");
  mouseHalo = loadImage("halo.png");
  
  //images for left room puzzle
  leftPuzzleBackground = loadImage("Left_Puzzle.jpg");
  leftRoomRoots = loadImage("Left_Room_Roots.png");
  leftPuzzlePiece0 = loadImage("piece0.png");
  leftPuzzlePiece1 = loadImage("piece1.png");
  leftPuzzlePiece2 = loadImage("piece2.png");
  leftPuzzlePiece3 = loadImage("piece3.png");
  
  // images for the right room puzzle
  rightPuzzlePiece00 = loadImage("arrow0.png");
  rightPuzzlePiece01 = loadImage("arrow1.png");
  rightPuzzlePiece02 = loadImage("arrow2.png");
  rightPuzzlePiece03 = loadImage("arrow3.png");
  rightPuzzlePiece04 = loadImage("arrow4.png");
  rightPuzzlePiece05 = loadImage("arrow5.png");
  rightPuzzlePiece06 = loadImage("arrow6.png");
  rightPuzzlePiece07 = loadImage("arrow7.png");
  rightPuzzlePiece08 = loadImage("arrow8.png");
  rightPuzzlePiece09 = loadImage("arrow9.png");
  rightPuzzlePiece10 = loadImage("arrow10.png");
  rightPuzzlePiece11 = loadImage("arrow11.png");
  rightPuzzlePiece12 = loadImage("arrow12.png");
  rightPuzzlePiece13 = loadImage("arrow13.png");
  rightPuzzlePiece14 = loadImage("arrow14.png");
  rightPuzzlePiece15 = loadImage("arrow15.png");
}

public void QuitOnEscPress()
{
  if (key == ESC)
  {
    exit();
  }
}

public void keyReleased() // cheat to get to the final room quickly by pressing r and t
{
  if (key == 'r' && returnedEye == false)
  {
    returnedEye = true;
  } 
  else if (key == 'r')
  {
    returnedEye = false;
  }
  
  if (key == 't' && returnedGem == false)
  {
    returnedGem = true;
  } 
  else if (key == 't')
  {
    returnedGem = false;
  }
}
//class Door_Opens_Anim
//{
//  PImage[] images;
//  int current = 0;
  
//  Door_Opens_Anim (PImage pSourceImage, int columns, int rows)
//  {
//    images = new PImage[rows*columns];
    
//    int imageWidth = (int)(pSourceImage.width/(float)columns);
//    int imageHeight = (int)(pSourceImage.height/(float)rows);
    
//    for (int y = 0; y < rows; y++) {
//      for (int x = 0; x < columns; x++) {
//        PImage sprite = createImage (imageWidth, imageHeight, ARGB);
//        sprite.copy(
//          pSourceImage, 
//          x * imageWidth, 
//          y * imageHeight,
//          imageWidth, 
//          imageHeight,
//          0, 0, imageWidth, imageHeight
//         );
//        images[x + y * columns] = sprite;
//      }
//    }
//  }
  
//  void draw(int x, int y)
//  {
//    push();
//    imageMode(CENTER);
//    image(images[current], x, y);
//    pop();
//  }
  
//  void next()
//  {
//    current = (current+1) % images.length;
//  }
//}
class Final_Scene
{
  public void update()
  {
    image(finalRoom,320,0);
    
  push();
  imageMode(CENTER);
  if(mouseX > 320 && mouseX < 1600 && mouseY < 960 && mouseY > 900)
  {
    cursor(mouseHalo);
  }
  else
  {
    cursor(ARROW);
  }
  pop();
  }
}
class GameObject //gameobject are items that are in the scenes and items are inside the inventory
{
  PImage objectImage;
  int objectX;
  int objectY;
  String objectName;
  int sizeX;
  int sizeY;
  
  GameObject (PImage pImage, int pObjectX, int pObjectY, String pObjectName, int pSizeX, int pSizeY)
  {
    objectImage = pImage;
    objectX = pObjectX;
    objectY = pObjectY;
    objectName = pObjectName;
    sizeX = pSizeX;
    sizeY = pSizeY;
  }
  
  public void update()
  {
    image(objectImage, objectX, objectY, sizeX, sizeY);
  }
  
  public void onObjectClick()
  {
    if(mouseX > objectX
      && mouseX < (objectX+sizeX)
      && mouseY > objectY
      && mouseY < (objectY+sizeY))
    {
      if (objectName == "Eye")
      {
        Inventory.add(new Item(eyeIcon, itemX, itemY, objectName, 100, 100));
        foundEye = true;
      }
      else if (objectName == "Gem")
      {
        Inventory.add(new Item(gemIcon, itemX, itemY, objectName, 80, 80));
        foundGem = true;
      }
    }
  }
}
class Item //gameobject are items that are in the scenes and items are inside the inventory
{
  int itemX;
  int itemY;
  PImage itemImage;
  String itemName;
  int sizeX;
  int sizeY;
  
  boolean itemSelected = false;
  
  Item (PImage pImage, int pItemX, int pItemY, String pItemName, int pSizeX, int pSizeY)
  {
    itemImage = pImage;
    itemX = pItemX;
    itemY = pItemY;
    itemName = pItemName;
    sizeX = pSizeX;
    sizeY = pSizeY;
  }
  
  public void draw()
  {
    if (itemSelected == true)
    {
      fill(0xffFAD7AC);
      rect(itemX-75,itemY-50,150,95);
    }
    
    image(itemImage,itemX,itemY, sizeX, sizeY);
    
    //if (mouseX < itemX+75
    //  && mouseX > itemX-75
    //  && mouseY < itemY+25
    //  && mouseY > itemY-50)
    //  {
    //    cursor(mouseHalo);
    //  }
    //  else
    //  {
    //    cursor(ARROW);
    //  }
  }
  
  public void mouseClicked()
  {
    if (mouseX < itemX+75
      && mouseX > itemX-75
      && mouseY < itemY+25
      && mouseY > itemY-50)
      {
        itemSelected = true;
      }
      else
      {
        itemSelected = false;
      }
  }
  
  public String itemName()
  {
    return itemName;
  }
}
class Left_Scene
{
  public void update()
  {
    image(leftRoom,320,0);
    
    
    
    // change mouse when hovering over something clickable
    push();
    imageMode(CENTER);
    if (mouseX > 1500 && mouseX < 1600 && mouseY < 960 && mouseY > 400) //right door
    {
      cursor(mouseHalo);
    }
    else if (mouseX > 320 && mouseX < 420 && mouseY > 250 && mouseY < 300) //puzzle
    {
      cursor(mouseHalo);
    }
    else
    {
      cursor(ARROW);
    }
    pop();
  }
  
  
}


class leftPuzzle {
  //click counter value
  int clickCntr;
}

class Left_Puzzle
{
  public void mouseClicked()
  {
    //change counter value with each click
    if (mouseX>479 && mouseX<780 && mouseY>354 && mouseY<660) {
      leftPiece.clickCntr++;
    }

    if (mouseX>799 && mouseX<1100 && mouseY>354 && mouseY<660) {
      middlePiece.clickCntr++;
    }

    if (mouseX>1119 && mouseX<1420 && mouseY>354 && mouseY<660) {
      rightPiece.clickCntr++;
    }
  }
  
  public void update()
  {
    image(leftPuzzleBackground, 320, 0);
    image(leftRoomRoots, 320, 0);
    
    push();
    imageMode(CENTER);
    if (mouseX>479 && mouseX<780 && mouseY>354 && mouseY<660 && leftPuzzleSolved == false) {
      cursor(mouseHalo);
    }
    else if (mouseX>799 && mouseX<1100 && mouseY>354 && mouseY<660 && leftPuzzleSolved == false) {
      cursor(mouseHalo);
    }
    else if (mouseX>1119 && mouseX<1420 && mouseY>354 && mouseY<660 && leftPuzzleSolved == false) {
      cursor(mouseHalo);
    }
    else if ((mouseX > 1540 && mouseX < 1600) || (mouseY > 900 && mouseY < 960))
    {
      cursor(mouseHalo);
    }
    else if(mouseX > (Eye.objectX)
      && mouseX < (Eye.objectX+Eye.sizeX)
      && mouseY > (Eye.objectY)
      && mouseY < (Eye.objectY+Eye.sizeY)
      && foundEye == false)
    {
      cursor(mouseHalo);
    }
    else
    {
      cursor(ARROW);
    }
    pop();

    //reset values over 4 back to 0
    if (leftPiece.clickCntr == 4) {
      leftPiece.clickCntr = 0;
    }

    if (middlePiece.clickCntr == 4) {
      middlePiece.clickCntr = 0;
    }

    if (rightPiece.clickCntr == 4) {
      rightPiece.clickCntr = 0;
    }
    
    if (leftPuzzleSolved == false)
    {
      //change the image with each counter value increase
      if (leftPiece.clickCntr == 0) {
        image(leftPuzzlePiece0, 480, 355);
      }
      else if (leftPiece.clickCntr == 1) {
        image(leftPuzzlePiece1, 480, 355);
      }
      else if (leftPiece.clickCntr == 2) {
        image(leftPuzzlePiece2, 480, 355);
      }
      else if (leftPiece.clickCntr == 3) {
        image(leftPuzzlePiece3, 480, 355);
      }
  
  
      if (middlePiece.clickCntr == 0) {
        image(leftPuzzlePiece0, 800, 355);
      }
      else if (middlePiece.clickCntr == 1) {
        image(leftPuzzlePiece1, 800, 355);
      }
      else if (middlePiece.clickCntr == 2) {
        image(leftPuzzlePiece2, 800, 355);
      }
      else if (middlePiece.clickCntr == 3) {
        image(leftPuzzlePiece3, 800, 355);
      }
  
      if (rightPiece.clickCntr == 0) {
        image(leftPuzzlePiece0, 1120, 355);
      }
      else if (rightPiece.clickCntr == 1) {
        image(leftPuzzlePiece1, 1120, 355);
      }
      else if (rightPiece.clickCntr == 2) {
        image(leftPuzzlePiece2, 1120, 355);
      }
      else if (rightPiece.clickCntr == 3) {
        image(leftPuzzlePiece3, 1120, 355);
      }
    }
    else
    {
      if (foundEye == false)
      {
        //rect(1175,275,100,100);
        //image(eyeIconSmall,1000,900);
        Eye.update();
      }
    }
    
    

    //win condition for the puzzle
    if (leftPiece.clickCntr == 1) {
      leftSolved = true;
      //println("Left Solved");
    }
    else {
      leftSolved = false;
    }
    
    if (middlePiece.clickCntr == 0) {
      middleSolved = true;
      //println("Middle Solved");
    }
    else {
      middleSolved = false;
    }
    
    if (rightPiece.clickCntr == 3) {
      rightSolved = true;
      //println("Right Solved");
    }
    else {
      rightSolved = false;
    }
    
    if (leftSolved == true && middleSolved == true && rightSolved == true) {
      leftPuzzleSolved = true;
      //println("Left Puzzle Solved");
    }
    // solution is red left - blue down - orange right - green left
      
  }
}
class Main_Scene 
{
  public void update()
  {
    if (returnedEye == false || returnedGem == false) //displaying the returned items and checking whether the door is unlocked.
    {
      image(mainRoom,320,0);
      
      if (returnedEye == true)
      {
        image(statueEye,320,0);
      }
      
      if (returnedGem == true)
      {
        image(statueGem,320,0);
      }
    }
    else if (returnedEye == true && returnedGem == true)
    {
      image(doorOpens,320,0);
      doorUnlocked = true;
    }
    
    // change mouse when hovering over something clickable
    push();
    imageMode(CENTER);
    if (mouseX > 1500 && mouseX < 1600 && mouseY < 960 && mouseY > 400) //right door
    {
      cursor(mouseHalo);
    }
    else if (mouseX < 420 && mouseX > 320 && mouseY < 960 && mouseY > 400) //left door
    {
      cursor(mouseHalo);
    }
    else if (mouseX > 850 && mouseX < 1025 && mouseY > 375 && mouseY < 725 && doorUnlocked == true)// central door
    {
      cursor(mouseHalo);
    }
    else
    {
      cursor(ARROW);
    }
    pop();
  }
  
  public void mouseClicked()
  {
    int deleteItem = -1;
    
    if (foundEye == true && returnedEye == false // check if the correct item is seleced and use it
      && mouseX > 1175
      && mouseX < 1250
      && mouseY > 275
      && mouseY < 350)
    {
      Item eyeItem = null;
      
      
      for (int i = 0; i < Inventory.size(); ++i)
      {
        Item item = Inventory.get(i);
        if (item.itemName().equals("Eye") && item.itemSelected == true)
        {
          returnedEye = true;
          eyeItem = item;
          deleteItem = i;
        }
      }
      
      if (eyeItem != null)
      {
        if (returnedEye == true && eyeItem.itemName().equals("Eye"))
        {
          Inventory.remove(deleteItem);
          deleteItem = -1;
        }
      }
    }
    
    if (foundGem == true && returnedGem == false // check if the correct item is seleced and use it
      && mouseX > 1160
      && mouseX < 1235
      && mouseY > 475
      && mouseY < 550)
    {
      Item gemItem = null;
      
      for (int i = 0; i < Inventory.size(); ++i)
      {
        Item item = Inventory.get(i);
        if (item.itemName().equals("Gem") && item.itemSelected == true)
        {
          returnedGem = true;
          gemItem = item;
          deleteItem = i;
        }
      }
      
      if (gemItem != null)
      {
        if (returnedGem == true && gemItem.itemName().equals("Gem"))
        {
          Inventory.remove(deleteItem);
          deleteItem = -1;
        }
      }
    }
  }
}
class Right_Scene
{
  public void update()
  {
    image(rightRoom,320,0);
    
    if (foundGem == false && rightPuzzleSolved == true)
    {
      //image(statueGem,320,0);
      Gem.update();
    }

    //reset values over 4 back to 0
    if (trPiece.clickCntr == 4) {
      trPiece.clickCntr = 0;
    }

    if (tlPiece.clickCntr == 4) {
      tlPiece.clickCntr = 0;
    }

    if (brPiece.clickCntr == 4) {
      brPiece.clickCntr = 0;
    }

    if (blPiece.clickCntr == 4) {
      blPiece.clickCntr = 0;
    }

    //change the image with each counter value increase
    if (trPiece.clickCntr == 0) {
      image(rightPuzzlePiece00, 750, 250);
    }
    if (trPiece.clickCntr == 1) {
      image(rightPuzzlePiece01, 750, 250);
    }
    if (trPiece.clickCntr == 2) {
      image(rightPuzzlePiece02, 750, 250);
    }
    if (trPiece.clickCntr == 3) {
      image(rightPuzzlePiece03, 750, 250);
    }

    if (tlPiece.clickCntr == 0) {
      image(rightPuzzlePiece04, 1025, 250);
    }
    if (tlPiece.clickCntr == 1) {
      image(rightPuzzlePiece05, 1025, 250);
    }
    if (tlPiece.clickCntr == 2) {
      image(rightPuzzlePiece06, 1025, 250);
    }
    if (tlPiece.clickCntr == 3) {
      image(rightPuzzlePiece07, 1025, 250);
    }

    if (brPiece.clickCntr == 0) {
      image(rightPuzzlePiece08, 750, 450);
    }
    if (brPiece.clickCntr == 1) {
      image(rightPuzzlePiece09, 750, 450);
    }
    if (brPiece.clickCntr == 2) {
      image(rightPuzzlePiece10, 750, 450);
    }
    if (brPiece.clickCntr == 3) {
      image(rightPuzzlePiece11, 750, 450);
    }

    if (blPiece.clickCntr == 0) {
      image(rightPuzzlePiece12, 1025, 450);
    }
    if (blPiece.clickCntr == 1) {
      image(rightPuzzlePiece13, 1025, 450);
    }
    if (blPiece.clickCntr == 2) {
      image(rightPuzzlePiece14, 1025, 450);
    }
    if (blPiece.clickCntr == 3) {
      image(rightPuzzlePiece15, 1025, 450);
    }

    //win condition for the puzzle
    if (trPiece.clickCntr == 1) {
      topRightSolved = true;
      //println("Top Right Solved");
    }
    else {
      topRightSolved = false;
    }
    
    if (tlPiece.clickCntr == 1) {
      topLeftSolved = true;
      //println("Top Left Solved");
    }
    else {
      topLeftSolved = false;
    }
    
    if (brPiece.clickCntr == 1) {
      bottomRightSolved = true;
      //println("Bottom Right Solved");
    }
    else {
      bottomRightSolved = false;
    }
    
    if (blPiece.clickCntr == 1) {
      bottomLeftSolved = true;
      //println("Bottom Left Solved");
    }
    else {
      bottomLeftSolved = false;
    }

    if (topRightSolved == true && topLeftSolved == true && bottomRightSolved == true && bottomLeftSolved == true) {
      rightPuzzleSolved = true;
      //println("Right Puzzle Solved");
    }
    else
    {
      rightPuzzleSolved = false;
    }
    
    push();
    imageMode(CENTER);
    if (mouseX < 420 && mouseX > 320 && mouseY < 960 && mouseY > 400) //left door
    {
      cursor(mouseHalo);
    }
    else if(mouseX > (Gem.objectX) //gameobject
      && mouseX < (Gem.objectX+Gem.sizeX)
      && mouseY > (Gem.objectY)
      && mouseY < (Gem.objectY+Gem.sizeY)
      && foundGem == false && rightPuzzleSolved == true)
    {
      cursor(mouseHalo);
    }
    else if (mouseX>750 && mouseX<900 && mouseY>250 && mouseY<400) {
      cursor(mouseHalo);
    }
    else if (mouseX>1025 && mouseX<1175 && mouseY>250 && mouseY<400) {
      cursor(mouseHalo);
    }
    else if (mouseX>750 && mouseX<900 && mouseY>450 && mouseY<600) {
      cursor(mouseHalo);
    }
    else if (mouseX>1025 && mouseX<1175 && mouseY>450 && mouseY<600) {
      cursor(mouseHalo);
    }
    else
    {
      cursor(ARROW);
    }
    pop();
    
  }
  
  public void mouseClicked()
  {
      //change counter value with each click
    if (mouseX>750 && mouseX<900 && mouseY>250 && mouseY<400) {
      trPiece.clickCntr++;
    }
    else if (mouseX>1025 && mouseX<1175 && mouseY>250 && mouseY<400) {
      tlPiece.clickCntr++;
    }
    else if (mouseX>750 && mouseX<900 && mouseY>450 && mouseY<600) {
      brPiece.clickCntr++;
    }
    else if (mouseX>1025 && mouseX<1175 && mouseY>450 && mouseY<600) {
      blPiece.clickCntr++;
    }
  }
}


class rightPuzzle {
  //click counter value
  int clickCntr;
}


public void SceneManager()
{
  switch(currentScene) // tells the program which scene to show.
  {
    case "main_Scene": 
      mainScene.update();
      break;
    case "right_Scene":  
      rightScene.update();
      break;
    case "left_Scene": 
      leftScene.update();
      break;
    case "left_Scene_Puzzle":
      leftPuzzleScene.update();
      break;
    case "final_Scene":
      finalScene.update();
      break;
    default:
      mainScene.update();
      println("missing scene. did you make a typo?");
      break;
  }
}

public void mouseClicked() 
{
  switch(currentScene) // handles scene navigation
  {
    case "main_Scene":
      if (mouseX > 1500 && mouseX < 1600 && mouseY < 960 && mouseY > 400)
      {
        currentScene = "right_Scene";
      }
      if (mouseX < 420 && mouseX > 320 && mouseY < 960 && mouseY > 400)
      {
        currentScene = "left_Scene";
      }
      if (mouseX > 825 && mouseX < 1025 && mouseY > 375 && mouseY < 725 && doorUnlocked == true)
      {
        currentScene = "final_Scene";   
      }
      mainScene.mouseClicked();
    break;
      
    case "right_Scene":
    rightScene.mouseClicked();
      if (mouseX < 420 && mouseX < 1320 && mouseY < 960 && mouseY > 400)
      {
        currentScene = "main_Scene";
      }
    break;
      
    case "left_Scene":
      if (mouseX > 1500 && mouseX < 1600 && mouseY < 960 && mouseY > 400)
      {
        currentScene = "main_Scene";
      }
      
      if (mouseX > 320 && mouseX < 420 && mouseY > 250 && mouseY < 300)
      {
        currentScene = "left_Scene_Puzzle";
      }
    break;
    
    case "left_Scene_Puzzle":
      leftPuzzleScene.mouseClicked();
      if ((mouseX > 1540 && mouseX < 1600) || (mouseY > 900 && mouseY < 960))
      {
        currentScene = "left_Scene";
      }
    break;
      
    case "final_Scene":
      if (mouseX > 320 && mouseX < 1600 && mouseY < 960 && mouseY > 900)
      {
        currentScene = "main_Scene";
      }
    break;
    
    default:
      currentScene = "main_Scene";
      println("missing scene. did you make a typo?");
      break;
  }
  
  switch (currentScene) // handles item click detection
  {
    case "left_Scene_Puzzle":
      if (foundEye == false && leftPuzzleSolved == true)
      {
        Eye.onObjectClick();
      }
    break;
    
    case "right_Scene":
      if (foundGem == false && rightPuzzleSolved == true)
      {
        Gem.onObjectClick();
      }
    break;
  }
  
  for (Item item : Inventory)
  {
    item.mouseClicked();
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Maya_Maze" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
